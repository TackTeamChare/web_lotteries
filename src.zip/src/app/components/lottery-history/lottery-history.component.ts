import { Component } from '@angular/core';

@Component({
  selector: 'app-lottery-history',
  templateUrl: './lottery-history.component.html',
  styleUrls: ['./lottery-history.component.css']
})
export class LotteryHistoryComponent {

}
// แสดงรายละเอียดของสลากหลังจากค้นหา
